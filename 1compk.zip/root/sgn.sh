sudo apt-get update -y && sudo apt upgrade -y

sudo apt install nala -y && sudo nala fetch

sudo apt install gdm3 -y

sudo apt install cmst cbm 7zip pcmanfm ghex galculator gparted grub-customizer mtools mmv zstd lz4 binfmt-support xfonts-thai-nectec libqt5widgets5 libusb-1.0-0-dev ntfs-3g neofetch numix-gtk-theme numix-icon-theme numix-icon-theme-circle gnome-tweaks mousepad mousetweaks nemo nemo-data nemo-fileroller nemo-font-manager viewnior surf exfatprogs -y

sudo apt install anacron apt-xapian-index at-spi2-core colord cups dbus-x11 dmz-cursor-theme dconf-cli eject foomatic-db-compressed-ppds gdebi gnome-calculator gnome-control-center gnome-disk-utility gnome-desktop3-data gnome-keyring gnome-menus gnome-screenshot gnome-disk-utility gnome-system-monitor gnome-terminal gnome-session gnome-shell inputattach libnotify-bin libpulsedsp lm-sensors pavucontrol printer-driver-all profile-sync-daemon pulseaudio pulseaudio-module-bluetooth software-properties-gtk system-config-printer tracker tracker-extract tracker-miner-fs upower x11-apps x11-session-utils x11-utils x11-xserver-utils xarchiver xdg-user-dirs xdg-user-dirs-gtk xfonts-base xserver-xorg xwayland zenity -y

sudo nala clean

sudo reboot
